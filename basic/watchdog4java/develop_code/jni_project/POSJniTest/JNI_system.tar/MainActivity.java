package com.example.posjnitest;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

import com.ipaloma.posjniproject.jni.NativeUtilitiesClass;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String cmdline = "sqlite3 /sdcard/jni_test.db < /data/init_sh.sql";
        
        NativeUtilitiesClass nu = new NativeUtilitiesClass();
        int ret = nu.execCmdLine(cmdline);
        System.out.println("Get the return value:" + ret);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
